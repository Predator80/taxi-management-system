Free Download Source Code "Car Taxi Management System"

FIRST Download

1.XAMPP

2."TEXT EDITOR" NOTEPAD++ OR SUBLIME TEXT 3 / ETC.

3"cms"

4. Download the zip file/ download winrar

5. Extract the file and copy "cms" folder

6.Paste inside root directory/ where you install xammp local disk C: drive D: drive E: paste: (for xampp/htdocs, 

7. Open PHPMyAdmin (http://localhost/phpmyadmin)

8. Create a database with name cms_db.SQL

6. Import cms_db.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/cms

**LOGIN DETAILS** 

Admin
user: admin
pass: admin123	

create your own user


****** https:1sourcecodr.blogspot.com ******
Subcribe my You tube Channel **** 1 Source code ****